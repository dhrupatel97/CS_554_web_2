import React, { Component } from 'react';

class Home extends Component {
    state = {  }
    render() { 
        return (
            <div>
                <p>
                <h2>The Marvel Cinematic Universe is an American media franchise and shared universe centered on a series of superhero films, independently produced by Marvel Studios and based on characters that appear in American comic books published by Marvel Comics.</h2>
                </p>

                <p className='hometext'>
                <h3>To know More About Marvel, Click Above Links to Characters, Comics, Series</h3>
                </p>
		    </div>
        );
    }
}
 
export default Home;